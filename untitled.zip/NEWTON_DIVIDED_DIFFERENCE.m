function Coefficient = NEWTON_DIVIDED_DIFFERENCE(Array_Nodes, Array_Values)
    % Given nodes and values of f at the nodes, output the kth Newton's
    % divided differences f[x0,...,xk], for all k in {0,..., length(Array_Nodes)}

    % To obtain f[x_n, ..., x_{n-k}, simply set
    % Array_Nodes = fliplr(Array_Nodes) and Array_Values = fliplr(Array_Values)
    n = length(Array_Nodes);
    MATRIX = zeros(n);
    MATRIX(:,1) = transpose(Array_Values);
    for i = 2:n
        x1 = Array_Nodes(1,i);
        for j = 2:i
            x0 = Array_Nodes(1,i-j+1); 
            MATRIX(i,j) = (MATRIX(i,j-1) - MATRIX(i-1,j-1))/(x1-x0);
        end
    end
    Coefficient = diag(MATRIX);
    fprintf(" k    f[x_0,...,x_k]   \n")
    fprintf("--------------------------\n")
    for k = 1:n
        Divided_Diff_k = Coefficient(k,1);
        X = [k-1 Divided_Diff_k];
        fprintf("%2d  %12.8f \n",X)
    end
end
