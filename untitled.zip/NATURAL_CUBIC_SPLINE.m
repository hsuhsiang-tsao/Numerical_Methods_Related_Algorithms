function Coefficient = NATURAL_CUBIC_SPLINE(Array_Nodes, Array_F)
% S(x) = S_j(x) = a_j + b_j(x-x_j)+ c_j(x-x_j)^2 + d_j(x-x_j)^3
    N = length(Array_Nodes);
    H = [Array_Nodes(2)-Array_Nodes(1)];
    A = [0];
    C = [1:N];
    Coefficient =[];
    for i = 2:N-1
        H(i) = Array_Nodes(i+1)-Array_Nodes(i);
        A(i) = (3/H(i))*(Array_F(i+1)-Array_F(i)) - (3/H(i-1))*(Array_F(i)-Array_F(i-1));
    end
    L = [1];
    m = [0];
    z = [0];
    for i = 2:N-1
        L(i) = 2*(Array_Nodes(i+1)-Array_Nodes(i-1)) - H(i-1)*m(i-1);
        m(i) = H(i)/L(i);
        z(i) = (A(i)-H(i-1)*z(i-1))/L(i);
    end
    L(N) = 1;
    z(N) = 0;
    C(N) = 0;
    fprintf(' j        a_j          b_j            c_j          d_j\n')
    fprintf('----------------------------------------------------------\n')
    for j = N-1:-1:1
        C(j) = z(j)-m(j)*C(j+1);
        bj = (Array_F(j+1)-Array_F(j))/H(j) - H(j)*(C(j+1)+2*C(j))/3;
        dj = (C(j+1)-C(j))/(3*H(j));
        X = [j-1 Array_F(j) bj C(j) dj];
        fprintf("%2d  %12.8f  %12.8f  %12.8f  %12.8f \n",X)
        Coefficient(end+1,:) = X;
    end
end