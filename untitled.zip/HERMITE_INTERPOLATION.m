function Coefficient = HERMITE_INTERPOLATION(Array_Nodes, Array_f,Array_df)
    % Array_f = [f(x_0),...,f(x_n)], Array_df = [df(x_0),...,df(x_n)]
    % Output [C_0 C_1 ... C_{2n+1}] such that 
    % H(x) = C_0 + C_1(x-x_0) + C_2(x-x_0)^2 + C_3(x-x_0)^2(x-x_1) +
    % C_4(x-x_0)^2(x-x_1)^2 + ... + C_{2n+1}(x-x_0)^2(x-x_1)^2...(x-x_{n-1})^2(x-x_n)
    N = length(Array_Nodes);
    MATRIX = zeros(2*N);
    Z = [];
    for i = 1:N
        xi = Array_Nodes(i);
        fxi = Array_f(i);
        Z(2*i-1) = xi; 
        Z(2*i) = xi;
        MATRIX(2*i-1,1) = fxi;
        MATRIX(2*i,1) = fxi;
        MATRIX(2*i,2) = Array_df(i);
        if i > 1
            MATRIX(2*i-1,2) = (MATRIX(2*i-1,1)-MATRIX(2*i-2,1))/(Z(2*i -1)-Z(2*i -2));
        end
        %MATRIX
    end
    for i = 3:(2*N)
        for j = 3:i
            MATRIX(i,j) = (MATRIX(i,j-1)-MATRIX(i-1,j-1))/(Z(i)-Z(i-j+1));
        end
    end
    Coefficient = diag(MATRIX);
    %MATRIX
end