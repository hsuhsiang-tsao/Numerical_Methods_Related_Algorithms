function DATA = SECAND_METHOD(f, p0, p1, TOL, N) 
    DATA = [];
    fprintf('  n      p_(n-2)      p_(n-1)        p_n       absErr(seq)       f(p)         \n');
    fprintf('--------------------------------------------------------------------------\n');
    for n = [2:N]
       fp0 = f(p0); %p_0 = p_{n-2}    f(p_{n-2})  
       fp1 = f(p1); %p_1 = p_{n-1}    f(p_{n-1})
       p = p1 - fp1 * (p1-p0)/(fp1 - fp0); 
       fp = f(p);
       absErr = abs(p-p1);
       X = [n p0 p1 p absErr fp];
       fprintf('%3d  %12.8f  %12.8f  %12.8f  %12.8f  %12.8f\n',X)
       DATA(end+1,:) = X;
       if absErr < TOL
           fprintf('\n  p_%d=%12.8f', [n p])
           return
       end
       p0 = p1;
       fp0 = fp1;
       p1 = p;
       fp1 = fp;
    end
    fprintf('\n Method failed after N = %3d iterations.', N);
end