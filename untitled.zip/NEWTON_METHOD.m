function DATA = NEWTON_METHOD(f, df, p0, TOL, N) 
    DATA = [];
    fprintf('  n      p_{n-1}           p_n        absErr(seq)        f(p)        df(p)  \n');
    fprintf('--------------------------------------------------------------------------\n');
    for n = [1:N]
       fp0 = f(p0); 
       dfp0 = df(p0);
       p = p0 - fp0/dfp0;
       fp = f(p); 
       dfp = df(p);
       absErr = abs(p-p0);
       X = [n p0 p absErr fp dfp];
       fprintf('%3d  %12.8f  %12.8f  %12.8f  %12.8f  %12.8f\n',X)
       DATA(end+1,:) = X;
       if absErr < TOL
           fprintf('\n  p_%d=%12.8f', [n p])
           return
       end
       p0 = p;
    end
    fprintf('\n Method failed after N = %3d iterations.', N);
end