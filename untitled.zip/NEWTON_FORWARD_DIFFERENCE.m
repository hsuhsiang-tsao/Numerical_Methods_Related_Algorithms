function approx = NEWTON_FORWARD_DIFFERENCE(x, Array_Nodes, Array_Values)
    % The nodes must be equistanced
    % Lagrange interpolation via forward difference
    DivDiff = NEWTON_DIVIDED_DIFFERENCE(Array_Nodes, Array_Values);
    n = length(DivDiff);
    h = Array_Nodes(2)-Array_Nodes(1);
    s = (x-Array_Nodes(1))/h;
    sum = 0;
    c = s;
    for k = n-1:-1:1
      sum = (s-k+1)*(sum + DivDiff(k+1)*(h^k));
    end
    approx = Array_Values(1)+ sum;
end