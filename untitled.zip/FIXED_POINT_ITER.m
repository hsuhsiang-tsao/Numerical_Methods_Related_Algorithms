% function DATA = FIXED_POINT_ITER(f, p0, TOL, N) 
    DATA = [];
    fprintf('  n       p_0        p_n=g(p_0)        absErr        f(p)  \n');
    fprintf('-----------------------------------------------------------\n');
    for n = [0:N]
       p = f(p0); 
       fp = f(p); 
       absErr = abs(p-p0);
       X = [n p0 p absErr fp];
       fprintf('%3d  %12.8f  %12.8f  %12.8f  %12.8f\n',X)
       DATA(end+1,:) = X;
       if absErr < TOL
           fprintf('\n  p_%d =%12.8f', [n p])
           return
       end
       p0 = p;
    end
    fprintf('\n Method failed after N = %3d iterations.', N);
end